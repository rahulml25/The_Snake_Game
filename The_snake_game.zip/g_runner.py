if __name__ == '__main__':
    import pygame
    import snakes as s
    pygame.mixer.init()
    s.Game()