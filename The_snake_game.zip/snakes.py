'''

Author: Rahul Mondal
Language: Python
Last Updated: 27th March, 2021

User Keys:
    
    1. Press SPACE to start the Game
    2. Press 0 or ESCAPE QUIT to Quit the Game
    3. Press 2 or Key Up to move the Snake 🐍 Upwards
    4. Press 8 or Key Up to move the Snake 🐍 Downwards
    5. Press 4 or Key Left to move The Snake 🐍 Left
    6. Press 6 or Key Right to move the Snake 🐍 Right
    7. There is two cheat code which is hidden *** 😜

What's new:
    
    1. You can enable child mode for children 😊
    2. There is a new cheat code which is hidden*** 😜

'''

# Importing Modules

import pygame
from pygame.locals import *
import random
import time
import os

# Colours
red = (255,0,0)
white = (255,255,255)
black = (0,0,0)
semi_white = (200,200,200)
light_pink = (246, 205, 230)

# Game Variables
SIZE = 40
FPS = 144

# Window size
wight = 720 # Screen Wight
height = 840 # Screen Height

# Game Type
device = 'phone' # 'comp'
child_mode = True # False # It is child mode. to enable child mode type 'child_mode = True' here. and type 'child_mode = False' to disable child mode 😊

# Defining to return random object position
def random_int(type):
    return random.randint(1,((type/SIZE)-2))*SIZE

# Defining Apple 🍏 object
class Apple:
    # Defining variables for Apple 🍏 object
    def __init__(self, parent_screen):
        # Importing screen 
        self.parent_screen = parent_screen
        # Importing image for Apple 🍏 object
        self.image = pygame.image.load("resources/apple.jpg").convert()
        
        # Exciting random number for Apple 🍏 starting position
        self.x = random_int(wight)
        self.y = random_int(height)
    
    # Definition to draw Apple 🍎
    def draw(self):
        self.parent_screen.blit(self.image, (self.x, self.y))
        pygame.display.flip()
    
    # Definition to move the Apple 🍎 if ate by by the Snake 🐍
    def move(self):
        self.x = random_int(wight)
        self.y = random_int(height)
        
    def near_snake(self, snake_x, snake_y, snake_direction):
        
        if snake_x - (SIZE*3) >= 0 and snake_direction == 'left':
            self.x = snake_x - (SIZE*2)
            self.y = snake_y
            
        if snake_x + (SIZE*3) <= wight and snake_direction == 'right':
            self.x = snake_x + (SIZE*2)
            self.y = snake_y
            
        if snake_y - (SIZE*3) >= 0 and snake_direction == 'up':
            self.x = snake_x
            self.y = snake_y - (SIZE*2)
            
        if snake_y + (SIZE*3) <= height and snake_direction == 'down':
            self.x = snake_x
            self.y = snake_y + (SIZE*2)

        self.draw()

# Defining Snake 🐍 object
class Snake:
    # Defining variables for Snake 🐍 object
    def __init__(self, parent_screen):
        # Importing screen
        self.parent_screen = parent_screen
        
        # Importing all types of Snake 🐍 Heads 
        self.h_L = pygame.image.load("resources/all_heads/head_L.jpg") # Head for Left direction
        self.h_R = pygame.image.load("resources/all_heads/head_R.jpg") # Head for Right direction
        self.h_U = pygame.image.load("resources/all_heads/head_U.jpg") # Head for Up direction
        self.h_D = pygame.image.load("resources/all_heads/head_D.jpg") # Head for Down direction
        
        # Importing Snake 🐍 body
        self.body = pygame.image.load("resources/body.jpg").convert()
        
        # Defining starting direction of Snake 🐍
        self.direction = None
        
        # Defining Snake 🐍 length
        self.length = 1
        # Making list for Snake 🐍 body and position
        self.x = [40] # List for 'X' axis
        self.y = [40] # List for 'Y' axis
        
        # Exciting random position for Snake 🐍 object
        self.x[0] = random_int(wight)
        self.y[0] = random_int(height)
        
        # Importing Snake 🐍 Head with the below function
        self.head = self.head_type()
        
        # Defining Game starting Score & High Score
        self.score = 0
        self.highscore = self.open_hiscore()
        
    # Defining for Snake 🐍 Game starting Head type
    def head_type(self):
        # Starting Head if Snake 🐍 is at Left side
        if self.x[0] >= (wight/2):
            return pygame.transform.scale(self.h_L, (SIZE, SIZE)).convert_alpha()
        
        # Starting Head if Snake 🐍 is at Right side
        if self.x[0] <= (wight/2):
            return pygame.transform.scale(self.h_R, (SIZE, SIZE)).convert_alpha()
        
    
    # Defining Function to move Snake 🐍 Left direction
    def move_left(self):
        self.direction = 'left'
        if child_mode:
            self.x[0] -= SIZE
        self.rotate_head()

    # Defining Function to move Snake 🐍 Right direction
    def move_right(self):
        self.direction = 'right'
        if child_mode:
            self.x[0] += SIZE
        self.rotate_head()

    # Defining Function to move Snake 🐍 Up direction
    def move_up(self):
        self.direction = 'up'
        if child_mode:
           self.y[0] -= SIZE
        self.rotate_head()

    # Defining Function to move Snake 🐍 Down direction
    def move_down(self):
        self.direction = 'down'
        if child_mode:
            self.y[0] += SIZE
        self.rotate_head()

    # Defining Function to rotate Snake 🐍 Head
    def rotate_head(self):
        # Defining condition to display Head turned to the Left direction
        if self.direction == 'left':
            self.head = pygame.transform.scale(self.h_L, (SIZE, SIZE)).convert_alpha()
            
        # Defining condition to display Head turned to the Right direction
        if self.direction == 'right':
            self.head = pygame.transform.scale(self.h_R, (SIZE, SIZE)).convert_alpha()
            
        # Defining condition to display Head turned to the Up direction
        if self.direction == 'up':
            self.head = self.head = pygame.transform.scale(self.h_U, (SIZE, SIZE)).convert_alpha()
            
        # Defining condition to display Head turned to the Down direction
        if self.direction == 'down':
            self.head = pygame.transform.scale(self.h_D, (SIZE, SIZE)).convert_alpha()
        
    # Defining Function to move the Snake 🐍 Head & body in a certain direction
    def walk(self):
        # Updating the body In stages
        for i in range(self.length-1,0,-1):
            self.x[i] = self.x[i-1]
            self.y[i] = self.y[i-1]

        # Updating the Snake 🐍 running direction
        if self.direction == 'left':
            self.x[0] -= SIZE # Running to the Left direction

        if self.direction == 'right':
            self.x[0] += SIZE # Running to the Right direction

        if self.direction == 'up':
            self.y[0] -= SIZE # Running Upward

        if self.direction == 'down':
            self.y[0] += SIZE # Running Downward

        self.draw() # After moving in a certain direction it draws the Snake 🐍

    # Opening High Score file to note it
    def open_hiscore(self):
        # Exciting the 'highscore.txt' text file if it doesn't exists
        if (not os.path.exists('resources/highscore.txt')):
            with open('resources/highscore.txt', 'w') as f:
                f.write(f'{self.score}')
        
        # Reading the 'highscore.txt' text file and returning the High Score as an Integer
        with open('resources/highscore.txt') as f:
            return int(f.read()) # Returning the High Score
    
    # Drawing the Snake 🐍 Head & it's body
    def draw(self):
        # Drawing Snake 🐍 Head
        self.parent_screen.blit(self.head, (self.x[0],self.y[0]))
        
        if not child_mode:
            # Drawing Snake 🐍 body if the length is greater than One (head only)
            if self.length >= 1:
                # Running while loop to draw the full body
                for i in range(1,self.length):
                    self.parent_screen.blit(self.body, (self.x[i], self.y[i]))

        pygame.display.flip()
    
    # Definition to increase the Snake 🐍 length & the score also
    def increase_length(self):
        self.length += 1 # Increasing Snake 🐍 length with One new body part
        self.score += 10 # Increasing Gamer'Score with 10 points
        self.x.append(-1) # Appending a random value in the Snake 🐍 list of 'X' axis
        self.y.append(-1) # Appending a random value in the Snake 🐍 list of 'Y' axis

    # Updating The High Score with the Score if the Score is greater than the High Score
    def update_highscore(self):
        self.highscore = self.score
        with open('resources/highscore.txt', 'w') as f:
                f.write(str(self.highscore))

# Defining Game Object
class Game:
    # Initial variables for Game Object
    def __init__(self):
        pygame.init() # Initialising pygame
        pygame.mixer.init() # Initialising pygame music runner

        pygame.display.set_caption("Snake And Apple Game by Rahul") # Naming The Game window
        self.surface = pygame.display.set_mode((wight, height)) # Exciting display to Show the game to the user
        
        self.snake = Snake(self.surface) # Calling Snake 🐍 object
        self.apple = Apple(self.surface) # Calling Apple 🍎 object
        
        self.welcome() # Automatically calling welcome Function to wish the user Welcome and to get command to stat the game or exit it
    
    # Defining Function to play the background music
    def play_background_music(self):
        pygame.mixer.music.load('resources/bg_music_1.mp3') # Loading the background music
        pygame.mixer.music.play(-1, 0) # Playbacking the background music

    # Defining Function to show text on the display. The font type, text size, font color and the position to show the text is changeable here
    def show_text(self, text, font_style, text_size, colour, position):
        text = pygame.font.SysFont(font_style, text_size).render(text, True, colour)
        self.surface.blit(text, position)
        self.update_screen()
    
    # Defining Function to manage the Game FPS (Frames per Second)
    def frames(self, FPS):
        pygame.time.Clock().tick(FPS)
    
    # Defining Function to play a sound if the Apple 🍎 is eaten or the Snake 🐍 is collided
    def play_sound(self, sound_name):
        # Condition to play the 'crash.mp3' Sound file
        if sound_name == "crash":
            sound = pygame.mixer.Sound("resources/crash.mp3")
        
        # Condition to play the 'ding.mp3' Sound file
        elif sound_name == 'ding':
            sound = pygame.mixer.Sound("resources/ding.mp3")

        pygame.mixer.Sound.play(sound) # Playing the Sound
    
    # Defining Function to update the Screen
    def update_screen(self):
        pygame.display.flip()
    
    # Defining Function to replace the Snake 🐍 & Apple 🍎 on a random position again after Game is over
    def reset(self):
        self.snake = Snake(self.surface)
        self.apple = Apple(self.surface)

    # Defining Function to check if the Snake 🐍 is collided with own body or ate the Apple 🍎
    def is_collision(self, x1, y1, x2, y2):
        if x1 >= x2 and x1 < x2 + SIZE:
            if y1 >= y2 and y1 < y2 + SIZE:
                return True
        else:
            return False

    # Defining Function to render the background image
    def render_background(self):
        # self.surface.fill(light_pink)
        background_image = pygame.image.load("resources/background.jpg") # Loading background image
        background_image = pygame.transform.scale(background_image, (wight, height)).convert_alpha() # Resizing the background image
        self.surface.blit(background_image, (0,0))
        self.update_screen()

    # Defining Function to welcome the user and to make the person known the entry and Escape command
    def entry_text(self):
        # Wishing Welcome
        self.show_text(f'Welcome to Snakes', None, 90, red,(70,300))
        # Entry command
        self.show_text(f'Press Space to Play Game', 'arial', 35, white, (160,800))

    # Defining Function to check if the Snake 🐍 is gone out of the Window
    def is_snake_out(self):
        # Out than 'X' or 'Y' axis
        if self.snake.x[0]<= 0 or self.snake.y[0]<0:
            self.play_sound('crash') # Playing 'crash.mp3' Sound which notifies that the Snake is out than 'X'or 'Y' axis
            raise "Collision Occurred" # Calling Exception and 'Game over'
        
        # Out than the screen Height or width
        if self.snake.x[0]>= wight or self.snake.y[0]>height:
            self.play_sound('crash') # Playing 'crash.mp3' Sound which notifies that the Snake is out than the screen Height or width
            raise "Collision Occurred" # Calling Exception and 'Game over'
        
    
    # Defining Welcome Function to show the starting and to run the game forward
    def welcome(self):
        start = False # Variable to initially start the Game
        self.render_background() # Rendering background
        self.entry_text() # Showing texts in the entry point
        self.update_screen()
        # Running While loop
        while not start:
            # Getting user pressed keys
            for event in pygame.event.get():
                # Conditioning the KEYDOWN user pressed key type
                if event.type == KEYDOWN:
                    # Defining action after SPACE key is pressed
                    if event.key == K_SPACE:
                        self.play_background_music()
                        self.run() # Starting the Game
                        start = True # Stopping the efficacy of the starting keys
                    if event.key == K_0 or event.key == K_ESCAPE:
                        start = True # Not starting the game, the reality is QUIT-ing the Game! 😅

                elif event.type == QUIT:
                    start = True # Not starting the game, the reality is QUIT-ing the Game! 😅
    
    # Defining the Play Function to make the game playable
    def play(self):
        self.surface.fill(black) # Erasing or filling the last surface with black colour
        self.render_background() # Rendering the background
        self.display_score() # Displaying Score and High Score
        if child_mode:
            self.snake.draw()
        
        if not child_mode:
            self.snake.walk() # Making the Snake running
        self.apple.draw() # Drawing the Apple 🍎
        self.update_screen() # Updating the screen surface

        self.is_snake_out() # Checking if the Snake 🐍 is out of the Window
        
        # Snake 🐍 eating apple condition
        if self.is_collision(self.snake.x[0], self.snake.y[0], self.apple.x, self.apple.y):
            self.play_sound("ding") # Playing Sound the notifies the Snake 🐍 has eaten the Apple 🍎
            self.snake.increase_length() # Increasing the Snake 🐍 Length & the Game point with 10 numbers
            self.apple.move() # Moving the Apple 🍎 on a random position
            self.update_screen()
        
        # Condition to Update the High Score and Note it
        if self.snake.score>= self.snake.highscore:
            self.snake.update_highscore() # Updating High Score
        
        # Running 'for loop' to check if Snake 🐍 has collided with itself
        for i in range(3, self.snake.length):
            if self.is_collision(self.snake.x[0], self.snake.y[0], self.snake.x[i], self.snake.y[i]):
                self.play_sound('crash') # Playing 'crash.mp3' Sound which notifies that the Snake is Collided with itself
                raise "Collision Occurred" # Calling Exception and 'Game over'
        
        
    # Defining Function to displace User Game Score & High Score
    def display_score(self):
        self.show_text(f"Score: {self.snake.score}  Highscore: {self.snake.highscore}", 'arial', 30, semi_white, (50,10))
    
    # Defining Function to display Game is over, user commands, Score and High Score after the 'Game over'
    def show_gameover(self):
        # Showing 'Game is over'
        self.show_text('Game is over!', None, 80, red, (50,300))
        # Showing User commands
        self.show_text('To play again press Enter', 'arial', 30, white, (50,400))
        self.show_text('To exit press 0', 'arial', 30, white, (50,450))
        
        # Showing User Score
        self.show_text(f'Your Score: {self.snake.score}', 'arial', 30, white, (50,700))
        # Showing User High Score
        self.show_text(f'High Score: {self.snake.highscore}', 'arial', 30, white, (460,700))

    # Defining Function to show 'Game is over'
    def game_over(self):
        self.render_background() # Rendering background
        pygame.mixer.music.pause() # Pausing the background music
        self.show_gameover() # Displaying Game over
        self.update_screen() # Updating Screen
    
    # Defining Function to run the Game
    def run(self):
        running = True # Initial Veriable to run the Game
        pause = False # Initial Veriable to pause the Game if 'Game is over'

        while running:
            # Running 'for loop' to get the User key commands
            for event in pygame.event.get():
                # Conditioning the KEYDOWN user pressed key type
                if event.type == KEYDOWN:
                    # Defining keys actions
                    if event.key == K_0 or event.key == K_ESCAPE:
                        running = False # Existing the Game
                    
                    # User key to 'Run the Game' again after 'Game is over'
                    if event.key == K_RETURN:
                        pygame.mixer.music.unpause()
                        pause = False
                    
                    # Restarting the Game
                    if event.key == K_1:
                        running = False
                        pygame.mixer.music.stop()
                        self.welcome()

                    # User keys when 'Game is Running'
                    if not pause:
                        if event.key == K_4 or event.key == K_LEFT:
                            self.snake.move_left() # Moveing the Snake 🐍 to the Left direction

                        if event.key == K_6 or event.key == K_RIGHT:
                            self.snake.move_right() # Moveing the Snake 🐍 to the Right direction

                        if device == 'phone':
                            if event.key == K_2 or event.key == K_UP:
                                self.snake.move_up() # Moveing the Snake 🐍 Upward

                            if event.key == K_8 or event.key == K_DOWN:
                                self.snake.move_down() # Moveing the Snake 🐍 Downward
                        
                        if device == 'comp':
                        
                            if event.key == K_2 or event.key == K_UP:
                                self.snake.move_down() # Moveing the Snake 🐍 Downward

                            if event.key == K_8 or event.key == K_DOWN:
                                self.snake.move_up() # Moveing the Snake 🐍 Upward
                        
                        # Cheat code to increase the Snake 🐍 length & User Score
                        if event.key == K_7:
                            self.snake.increase_length() # increasing the Game Score as cheating
                            self.update_screen() # Updating the screen

                        if not child_mode:
                            if event.key == K_9 or event.key == K_q:
                                self.apple.near_snake(self.snake.x[0], self.snake.y[0], self.snake.direction)

                # User key to QUIT the Game
                elif event.type == QUIT:
                    running = False
            try:

                # Running the Game If 'Game is not over'
                if not pause:
                    self.play() # Starts playing the Game

            # Defining Exception to
            except Exception as e:
                self.game_over() # Showing 'Game over'
                pause = True # Pausing the Game
                self.reset() # Replaces the Snake 🐍 & Apple 🍎 on a random position again after Game is over

            # time.sleep(.1)
            self.frames(FPS) # Managing Game FPS (Frames per Second)


'''

The Cheat codes:
    1. Press 7 to increase Your Score and the Snake 🐍 length
    2. Press q or 9 to import the Apple 🍎 near the Snake 🐍
    

'''

# Condition not to Execute the bellow codes in another programme if the Game file is imported in other programme
if __name__ == '__main__':
    Game() # Calling Game Class which automatically Displays the Game
